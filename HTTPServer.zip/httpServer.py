# Author: Sunil Lal

# This is a simple HTTP server which listens on port 8080, accepts connection request, and processes the client request
# in sepearte threads. It implements basic service functions (methods) which generate HTTP response to service the HTTP requests.
# Currently there are 3 service functions; default, welcome and getFile. The process function maps the requet URL pattern to the service function.
# When the requested resource in the URL is empty, the default function is called which currently invokes the welcome function.
# The welcome service function responds with a simple HTTP response: "Welcome to my homepage".
# The getFile service function fetches the requested html or img file and generates an HTTP response containing the file contents and appropriate headers.

# To extend this server's functionality, define your service function(s), and map it to suitable URL pattern in the process function.

import _thread
# This web server runs on python v3
# Usage: execute this program (python httpServer.py 8080), open your browser (preferably chrome) and type http://servername:8080
# e.g. if server.py and broswer are running on the same machine, then use http://localhost:8080
import base64
import os
from socket import *

from bs4 import BeautifulSoup

import form_handler
import iex_handler

serverSocket = socket(AF_INET, SOCK_STREAM)

serverPort = 8080
serverSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
serverSocket.bind(("", serverPort))

serverSocket.listen(5)
print('The server is running')


# Server should be up and running and listening to the incoming connections

# Extract the given header value from the HTTP request message
def getHeader(message, header):
	if message.find(header) > -1:
		value = message.split(header)[1].split()[0]
	else:
		value = None

	return value


# service function to fetch the requested file, and send the contents back to the client in a HTTP response.
def getFile(filename):
	try:
		# open and read the file contents. This becomes the body of the HTTP response
		f = open(filename, "rb")
		body = f.read()
		header = ("HTTP/1.1 200 OK\r\n\r\n").encode()

	except IOError:
		# Send HTTP response message for resource not found
		header = "HTTP/1.1 404 Not Found\r\n\r\n".encode()
		body = "<html><head></head><body><h1>404 Not Found</h1></body></html>\r\n"
	return header, body.encode()


# FGenerate http auth header for login
def authenticate(message):
	header = "HTTP/1.1 401 Unauthorized\r\nWWW-Authenticate: Basic\r\n".encode()
	body = "<html><head></head><body><h1>401 not authorized</h1></body></html>\r\n".encode()
	return header, body


# Sends 404 not found page
def pageNotFound(message):
	header = "HTTP/1.1 404 NOT_FOUND\r\n\r\n".encode()
	body = "<html><head></head><body><h1>404 Page not found!!</h1><a href="'index.html'">Back to Home Page</a></body></html>\r\n".encode()
	return header, body


# service function to generate HTTP response with a simple welcome message
def welcome(message):
	header = "HTTP/1.1 200 OK\r\n\r\n".encode()
	body = ("<html><head></head><body><h1>Welcome to my homepage</h1></body></html>\r\n").encode()

	return header, body


# default service function
def default(message):
	header, body = welcome(message)

	return header, body


# Opens path from root directory and pulls from pages folder
# used because pycharm had issues finding my files.
def openPath(file):
	ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
	indexFile = os.path.join(ROOT_DIR, 'pages/' + file)
	openFile = open(indexFile)
	read = openFile.read()
	return read


# Generates custom header and html body
def custom(header, body):
	newHeader = ("HTTP/1.1 " + header + "\r\n\r\n").encode()
	newBody = ("" + body + "\r\n").encode()
	return newHeader, newBody


# We process client request here. The requested resource in the URL is mapped to a service function which generates the HTTP reponse
# that is eventually returned to the client.
def process(connectionSocket):
	# Receives the request message from the client
	message = connectionSocket.recv(1024).decode()

	if len(message) > 1:
		# Extract the path of the requested object from the message
		# Because the extracted path of the HTTP request includes
		# a character '/', we read the path from the second character
		resource = message.split()[1][1:]

		# map requested resource (contained in the URL) to specific function which generates HTTP response
		if resource == "":
			# Obtain login details from the client
			responseHeader, responseBody = authenticate(message)
			# Check if login is required
			if (responseHeader, responseBody) == authenticate(message):
				for n in message.split("\n"):
					if "Authorization" in n:
						authCode = n.replace("Authorization: Basic ", "")
						authCode = base64.decodebytes(authCode.encode())
						if str(authCode) == "b'20012507:20012507'":
							body = openPath("index.html")
							body.encode("utf-8")
							responseHeader, responseBody = custom("200 OK", body)
		# Pathway handler area
		elif resource == "welcome":
			responseHeader, responseBody = welcome(message)
		elif resource == "index.html" or resource == "index":
			body = openPath("index.html")
			body.encode("utf-8")
			responseHeader, responseBody = custom("200 OK", body)
		elif resource == "portfolio.html" or resource == "portfolio":
			# prepare xml file for javascript to pull from
			getStocks = openPath("portfolio.xml")
			getStocks.encode("utf-8")
			body = openPath("portfolio.html")
			body.encode("utf-8")
			responseHeader, responseBody = custom("200 OK", body)
		elif resource == "research.html" or resource == "research":
			body = openPath("research.html")
			body.encode("utf-8")
			responseHeader, responseBody = custom("200 OK", body)
		elif resource == "portfolio.xml":
			body = openPath("portfolio.xml")
			body.encode("utf-8")
			responseHeader, responseBody = custom("200 OK", body)

		# Post pages that receive inputs.
		elif resource == "post_research.html":
			retrieveData = connectionSocket.recv(1024).decode()
			form_handler.researchStockSearch(retrieveData)
			post = openPath("post_research.html")
			post.encode("utf-8")
			responseHeader, responseBody = custom("200 OK", post)

		elif resource == "post_info.html":
			retrieveFormData = connectionSocket.recv(1024).decode()
			form_handler.formData(retrieveFormData)
			body = openPath("post_info.html")
			body.encode("utf-8")
			responseHeader, responseBody = custom("200 OK", body)
		else:
			responseHeader, responseBody = pageNotFound(message)

	connectionSocket.send(responseHeader)
	# Send the content of the HTTP body (e.g. requested file) to the connection socket
	connectionSocket.send(responseBody)
	# Close the client connection socket
	connectionSocket.close()


# Main web server loop. It simply accepts TCP connections, and get the request processed in seperate threads.
while True:
	# Set up a new connection from the client
	connectionSocket, addr = serverSocket.accept()
	# Clients timeout after 60 seconds of inactivity and must reconnect.
	connectionSocket.settimeout(60)
	# start new thread to handle incoming request
	_thread.start_new_thread(process, (connectionSocket,))
