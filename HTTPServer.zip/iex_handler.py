# IEX API Token
import json
from io import BytesIO
from json import JSONDecodeError

import pycurl

token = 'pk_16b9ca8a48a943f3a68118664e19269d'

# Gives general information about a stock
def stockInfo(stock):
    try:
        response_buffer = BytesIO()
        curl = pycurl.Curl()
        curl.setopt(curl.SSL_VERIFYPEER, False)
        curl.setopt(curl.URL, str("https://cloud.iexapis.com/stable/stock/"+stock+"/stats?token="+token))
        curl.setopt(curl.WRITEFUNCTION, response_buffer.write)
        curl.perform()
        curl.close()
        body = response_buffer.getvalue().decode('UTF-8')
        convertedDict = json.loads(body)
        symbol = stock
        cName = convertedDict.get("companyName")
        peRatio = convertedDict.get("peRatio")
        marketCap = convertedDict.get("marketcap")
        ftHigh = convertedDict.get("week52high")
        ftLow = convertedDict.get("week52low")
        myData = "Symbol: {}<br> Company Name: {}<br> PE Ratio: {}<br> Market Capitalization: {}<br> 52 Week High: {}<br> 52 Week Low: {}<br>".format(symbol, cName, peRatio, marketCap, ftHigh, ftLow)
        return myData
    except JSONDecodeError:
        print("An error occurred.")

# Gathers data points over 5 year period for stock
def chartInfo(stock):
    response_buffer = BytesIO()
    curl = pycurl.Curl()
    iex = 'https://cloud.iexapis.com/stable/stock/"' + stock + '"/chart/5y?chartCloseOnly=true&token=' + token
    # Set the curl options which specify the Google API server, the parameters to be passed to the API,
    # and buffer to hold the response
    curl.setopt(curl.SSL_VERIFYPEER, False)
    curl.setopt(curl.URL, iex)
    curl.setopt(curl.WRITEFUNCTION, response_buffer.write)
    curl.perform()
    curl.close()
    body = response_buffer.getvalue().decode('UTF-8')
    print(body)


def calculateGainLoss(stockSymbol):
    token = "pk_16b9ca8a48a943f3a68118664e19269d"
    iex = "https://cloud.iexapis.com/stable/stock/" + stockSymbol + "/quote?token=" + token
    response_buffer = BytesIO()
    curl = pycurl.Curl()
    curl.setopt(curl.SSL_VERIFYPEER, False)
    curl.setopt(curl.URL, iex)
    curl.setopt(curl.WRITEFUNCTION, response_buffer.write)
    curl.perform()
    curl.close()
    body = response_buffer.getvalue().decode('UTF-8')
    convertedDict = json.loads(body)
    price = convertedDict.get("iexRealtimePrice")
    latestQuote = convertedDict.get("latestPrice")
    if price != 0 and latestQuote != 0:
        gain_loss = (latestQuote - price) / price * 100
    else:
        gain_loss = "Undetermined"
    print("Gain/loss: ", gain_loss)
    return int(gain_loss)


