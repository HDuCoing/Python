import os
import iex_handler


def formData(message):
    formData = [param_expr.split("=", 1) for param_expr in message.split("&")]
    stock = str(formData[0][1])
    quantity = str(formData[1][1])
    price = str(formData[2][1])
    print("Stock: ", stock, "\nQuantity: ", quantity, "\nPrice", price)
    # adds all data to xml
    addToXml(stock, quantity, price, iex_handler.calculateGainLoss(stock))

def researchStockSearch(message):
    formdata = [param_expr.split("=", 1) for param_expr in message.split("&")]
    stock = formdata[0][1]
    ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
    indexFile = os.path.join(ROOT_DIR, 'pages/' + "post_research.html")
    opened = open(indexFile, "w+")
    origData = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Posted</title>
</head>
<body>
<a href="index.html">Home</a><br>
<a href="portfolio.html">Portfolio</a><br>
<a href="research.html">Research</a><br>
'''
    origData2 = '''</body>
</html>'''
    string = "{} {} {}".format(origData, iex_handler.stockInfo(stock), origData2)
    if stock != "":
        opened.write(string)
        opened.close()
        return iex_handler.stockInfo(stock)

def addToXml(stock, quantity, price, gainLoss):
    #fixme add if stock exists in old lines info
    ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
    indexFile = os.path.join(ROOT_DIR, 'pages/' + "portfolio.xml")
    x = open(indexFile, 'r')
    oldInfo = x.read()
    x.close()
    current = oldInfo.split('\n')
    oldLines = '\n'.join(current[:-1])
    x = open(indexFile, "w+")
    for i in range(len(oldLines)):
        x.write(oldLines[i])
    xmlData = ("\n  <stock> \n"
               "        <Stock>" + stock + "</Stock>\n"
                                           "      <Quantity>" + quantity + "</Quantity>\n"
                                                                           "        <Price>" + price + "</Price>\n"
                                                                                                       "        <GainLoss>" + str(
        float(gainLoss)) + "%" + "</GainLoss>\n" + "\n   </stock>\n" + "\n </StockInfo>")
    x.write(xmlData)
    x.close()
